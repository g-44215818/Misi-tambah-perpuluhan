# Misi Tambah Perpuluhan

Prototaip web Matematik Bahasa Melayu untuk murid Tahun 4–6 yang memerlukan latihan tambahan bagi operasi tambah nombor perpuluhan.

## Kandungan
- `index.html` — aplikasi lengkap (HTML, CSS dan JavaScript dalam satu fail).
- Tiada pemasangan atau pelayan diperlukan untuk mencuba; buka `index.html` dalam pelayar web.
- Markah hanya disimpan sementara dalam sesi pelayar dan tidak dihantar ke pelayan.

## Terbitkan menggunakan GitHub Pages
1. Log masuk ke https://github.com/ dan cipta repository baharu, contohnya `misi-tambah-perpuluhan`.
2. Pilih `Public` (atau tetapan yang sesuai untuk akaun/organisasi), kemudian cipta repository.
3. Muat naik `index.html` ke bahagian akar repository melalui **Add file → Upload files → Commit changes**.
4. Buka **Settings → Pages**.
5. Di bawah **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/(root)`, kemudian tekan **Save**.
7. Tunggu proses penerbitan selesai. GitHub akan memaparkan URL Pages pada bahagian Pages.
8. Buka URL tersebut pada telefon/iPad dan uji beberapa soalan.

## Nota pedagogi dan teknikal
- Tahap 1: nombor dengan satu tempat perpuluhan.
- Tahap 2: nombor sehingga dua tempat perpuluhan.
- Tahap 3: soalan yang lebih mencabar, termasuk peluang pengumpulan semula.
- Semakan jawapan menyokong titik atau koma perpuluhan.
- Ini prototaip awal. Sebelum digunakan untuk pentaksiran rasmi, guru disaran menguji soalan, arahan, kebolehcapaian dan ketepatan maklum balas.
